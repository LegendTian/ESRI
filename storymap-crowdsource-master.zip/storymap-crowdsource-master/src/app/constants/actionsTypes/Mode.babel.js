export const UPDATE_MODE = 'UPDATE_MODE';
