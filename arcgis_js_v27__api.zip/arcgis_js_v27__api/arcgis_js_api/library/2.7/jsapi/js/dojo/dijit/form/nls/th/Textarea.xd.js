window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.th.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.th.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "th", {"iframeEditTitle":"แก้ไขพื้นที่","iframeFocusTitle":"แก้ไขกรอบพื้นที่"});
}};});