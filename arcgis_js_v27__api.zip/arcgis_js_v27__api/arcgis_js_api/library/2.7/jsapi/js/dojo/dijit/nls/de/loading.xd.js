window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.de.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.de.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "de", {"loadingState":"Wird geladen...","errorState":"Es ist ein Fehler aufgetreten."});
}};});