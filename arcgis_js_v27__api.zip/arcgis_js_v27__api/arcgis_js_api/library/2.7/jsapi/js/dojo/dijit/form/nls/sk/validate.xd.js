window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.sk.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.sk.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "sk", {"rangeMessage":"Táto hodnota je mimo rozsah.","invalidMessage":"Zadaná hodnota nie je platná.","missingMessage":"Táto hodnota je vyžadovaná."});
}};});