window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pl.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pl.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "pl", {"rangeMessage":"Ta wartość jest spoza zakresu.","invalidMessage":"Wprowadzona wartość jest niepoprawna.","missingMessage":"Ta wartość jest wymagana."});
}};});