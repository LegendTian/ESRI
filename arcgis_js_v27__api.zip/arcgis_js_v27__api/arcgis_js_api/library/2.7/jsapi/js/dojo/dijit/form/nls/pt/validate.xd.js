window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pt.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pt.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "pt", {"rangeMessage":"Este valor está fora do intervalo. ","invalidMessage":"O valor inserido não é válido.","missingMessage":"Este valor é necessário."});
}};});