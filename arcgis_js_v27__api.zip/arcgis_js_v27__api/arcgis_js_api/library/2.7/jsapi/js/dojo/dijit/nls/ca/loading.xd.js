window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.ca.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.ca.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "ca", {"loadingState":"S'està carregant...","errorState":"Ens sap greu. S'ha produït un error."});
}};});