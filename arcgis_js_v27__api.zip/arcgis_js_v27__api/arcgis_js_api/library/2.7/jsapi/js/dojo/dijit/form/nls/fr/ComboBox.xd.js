window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.fr.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.fr.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "fr", {"previousMessage":"Choix précédents","nextMessage":"Plus de choix"});
}};});