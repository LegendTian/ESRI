window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.sl.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.sl.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "sl", {"iframeEditTitle":"urejevalno področje","iframeFocusTitle":"okvir urejevalnega področja"});
}};});