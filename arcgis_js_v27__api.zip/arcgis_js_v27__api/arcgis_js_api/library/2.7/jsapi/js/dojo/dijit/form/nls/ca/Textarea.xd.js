window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ca.Textarea"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ca.Textarea");dojo._xdLoadFlattenedBundle("dijit.form", "Textarea", "ca", {"iframeEditTitle":"àrea d'edició","iframeFocusTitle":"Marc de l'àrea d'edició"});
}};});