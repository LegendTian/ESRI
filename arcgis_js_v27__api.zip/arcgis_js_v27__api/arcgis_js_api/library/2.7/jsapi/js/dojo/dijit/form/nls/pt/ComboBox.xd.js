window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.pt.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.pt.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "pt", {"previousMessage":"Opções anteriores","nextMessage":"Mais opções"});
}};});