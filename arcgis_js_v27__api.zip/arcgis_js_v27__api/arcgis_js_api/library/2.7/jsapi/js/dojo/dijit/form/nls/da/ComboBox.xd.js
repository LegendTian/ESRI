window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.da.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.da.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "da", {"previousMessage":"Forrige valg","nextMessage":"Flere valg"});
}};});