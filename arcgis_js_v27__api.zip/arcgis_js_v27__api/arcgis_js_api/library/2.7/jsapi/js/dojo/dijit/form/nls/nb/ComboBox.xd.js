window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.nb.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.nb.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "nb", {"previousMessage":"Tidligere valg","nextMessage":"Flere valg"});
}};});