/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(_1,_2,_3){return {depends:[["provide","dijit.form.ComboButton"],["require","dijit.form.Button"]],defineResource:function(_4,_5,_6){if(!_4._hasResource["dijit.form.ComboButton"]){_4._hasResource["dijit.form.ComboButton"]=true;_4.provide("dijit.form.ComboButton");_4.require("dijit.form.Button");}}};});