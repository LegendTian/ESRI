window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "", {"previousMessage":"Previous choices","nextMessage":"More choices"});
}};});