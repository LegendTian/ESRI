window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.hu.ComboBox"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.hu.ComboBox");dojo._xdLoadFlattenedBundle("dijit.form", "ComboBox", "hu", {"previousMessage":"Előző menüpontok","nextMessage":"További menüpontok"});
}};});