window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.fr.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.fr.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "fr", {"rangeMessage":"Cette valeur n'est pas comprise dans la plage autorisée.","invalidMessage":"La valeur indiquée n'est pas correcte.","missingMessage":"Cette valeur est requise."});
}};});