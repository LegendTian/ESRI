window[esri._dojoScopeName||"dojo"]._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.form.nls.fi.validate"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.form.nls.fi.validate");dojo._xdLoadFlattenedBundle("dijit.form", "validate", "fi", {"rangeMessage":"Tämä arvo on sallitun alueen ulkopuolella.","invalidMessage":"Annettu arvo ei kelpaa.","missingMessage":"Tämä arvo on pakollinen."});
}};});