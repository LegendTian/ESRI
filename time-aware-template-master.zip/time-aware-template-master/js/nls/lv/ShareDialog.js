﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Kopīgot",
                heading: "Koplietot šo karti",
                url: "Kartes saite",
                embed: "Iedarināt karti",
                extent: "Koplietot pašreizējās kartes pārklājumu",
                size: "Izmēri (platums/augstums):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "E-pasts"
            }
        }
    })
);
