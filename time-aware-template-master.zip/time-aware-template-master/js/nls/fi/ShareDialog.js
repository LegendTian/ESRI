﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Jaa",
                heading: "Jaa tämä kartta",
                url: "Karttalinkki",
                embed: "Upota kartta",
                extent: "Jaa nykyisen kartan laajuus",
                size: "Koko (leveys/korkeus):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Sähköposti"
            }
        }
    })
);
