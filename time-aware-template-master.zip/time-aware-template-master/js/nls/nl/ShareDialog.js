﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Delen",
                heading: "Deze kaart delen",
                url: "Kaartkoppeling",
                embed: "Kaart inbedden",
                extent: "Huidige kaartextent delen",
                size: "Grootte (breedte/hoogte):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "E-mail"
            }
        }
    })
);
