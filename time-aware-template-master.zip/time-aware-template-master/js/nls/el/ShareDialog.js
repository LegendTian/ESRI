﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Κοινοποίηση",
                heading: "Κοινοποίηση αυτού του χάρτη",
                url: "Σύνδεσμος χάρτη",
                embed: "Ενσωμάτωση χάρτη",
                extent: "Κοινοποίηση χάρτη στην τρέχουσα έκταση",
                size: "Μέγεθος (πλάτος/ύψος):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Email"
            }
        }
    })
);
