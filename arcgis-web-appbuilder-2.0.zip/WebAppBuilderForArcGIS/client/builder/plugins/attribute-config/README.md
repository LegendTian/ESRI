* Public methods:
  * setAppConfig
* Published events:
  * configChanged