﻿define(
   ({
    _themeLabel: "Tema Cartellone",
    _layout_default: "Layout predefinito",
    _layout_right: "Layout a destra"
  })
);