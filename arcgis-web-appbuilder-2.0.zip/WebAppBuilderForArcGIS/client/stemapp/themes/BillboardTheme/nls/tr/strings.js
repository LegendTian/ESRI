﻿define(
   ({
    _themeLabel: "İlan Panosu Teması",
    _layout_default: "Varsayılan Düzen",
    _layout_right: "Doğru Düzen"
  })
);