﻿define(
   ({
    _themeLabel: "Billboard-thema",
    _layout_default: "Standaard lay-out",
    _layout_right: "Lay-out rechts"
  })
);