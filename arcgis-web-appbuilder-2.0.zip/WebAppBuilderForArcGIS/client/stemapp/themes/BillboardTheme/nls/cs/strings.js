﻿define(
   ({
    _themeLabel: "Motiv billboardu",
    _layout_default: "Výchozí rozvržení",
    _layout_right: "Rozložení vpravo"
  })
);