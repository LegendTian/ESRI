﻿define(
   ({
    _themeLabel: "บิลบอร์ดธีม",
    _layout_default: "โครงร่างตั้งต้น",
    _layout_right: "โครงร่างชิดขวา"
  })
);