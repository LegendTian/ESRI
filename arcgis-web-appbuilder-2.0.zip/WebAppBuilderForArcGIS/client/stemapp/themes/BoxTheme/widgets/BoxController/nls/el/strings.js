﻿define(
   ({
    _widgetLabel: "Στοιχείο ελέγχου του Box"
  })
);
