﻿define(
   ({
    _themeLabel: "Motyw Pole",
    _layout_default: "Układ domyślny",
    _layout_top: "Górny układ"
  })
);