﻿define(
   ({
    _themeLabel: "Tema da Caixa",
    _layout_default: "Layout Padrão",
    _layout_top: "Layout Superior"
  })
);