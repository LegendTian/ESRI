﻿define(
   ({
    _themeLabel: "框主题",
    _layout_default: "默认布局",
    _layout_top: "顶部布局"
  })
);