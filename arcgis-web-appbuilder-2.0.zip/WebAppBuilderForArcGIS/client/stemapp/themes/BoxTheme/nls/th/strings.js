﻿define(
   ({
    _themeLabel: "กล่องธีม",
    _layout_default: "โครงร่างตั้งต้น",
    _layout_top: "เลเอาท์บน"
  })
);