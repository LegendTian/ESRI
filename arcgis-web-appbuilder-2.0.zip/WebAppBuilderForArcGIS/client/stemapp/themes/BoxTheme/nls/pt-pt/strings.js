﻿define(
   ({
    _themeLabel: "Tema Caixa",
    _layout_default: "Layout Padrão",
    _layout_top: "Layout Topo"
  })
);