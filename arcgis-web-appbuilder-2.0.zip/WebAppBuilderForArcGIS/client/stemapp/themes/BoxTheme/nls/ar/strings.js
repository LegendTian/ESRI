﻿define(
   ({
    _themeLabel: "موضوع المربع",
    _layout_default: "تخطيط افتراضي",
    _layout_top: "التخطيط الطباعي العلوي"
  })
);