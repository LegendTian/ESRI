﻿define(
   ({
    _themeLabel: "Boxthema",
    _layout_default: "Standaard lay-out",
    _layout_top: "Bovenste lay-out"
  })
);