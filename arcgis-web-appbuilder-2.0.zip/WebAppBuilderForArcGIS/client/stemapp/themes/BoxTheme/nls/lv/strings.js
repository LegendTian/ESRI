﻿define(
   ({
    _themeLabel: "Lodziņa dizains",
    _layout_default: "Noklusējuma izkārtojums",
    _layout_top: "Augšdaļas izkārtojums"
  })
);