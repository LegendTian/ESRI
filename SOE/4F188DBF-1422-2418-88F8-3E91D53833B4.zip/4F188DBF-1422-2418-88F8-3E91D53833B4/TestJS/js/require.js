// Author: nicogis
// nicogis.blogspot.it
dojo.require("esri.map");
dojo.require("esri.toolbars.draw");
dojo.require("dijit.dijit"); // optimize: load dijit layer
dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dojox.widget.Toaster");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.form.Button");
dojo.require("dijit.form.TextBox");
dojo.require("dijit.Tooltip");
dojo.require("dijit.Dialog");
