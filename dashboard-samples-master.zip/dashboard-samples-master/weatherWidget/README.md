##Weather widget

This widget shows the weather observations for the map center. The widget refreshes automatically when map extent changes. 

To use this widget, you must sign up for and enter here a free Weather Underground Developer API key. Sign up at http://www.wunderground.com/weather/api/.

![image](https://cloud.githubusercontent.com/assets/4983864/16164707/8d33bbaa-3494-11e6-8bb3-fbc48ae0841f.png)

