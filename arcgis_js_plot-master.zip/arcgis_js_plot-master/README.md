#JavaScript api for arcigs PlotDraw
